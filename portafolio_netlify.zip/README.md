# Portafolio personal

Sitio estático creado con HTML, CSS y JavaScript básico.

## Publicar en Netlify desde GitHub

1. Sube estos archivos a la **raíz** de tu repositorio.
2. En Netlify, selecciona **Add new site → Import an existing project**.
3. Conecta GitHub y elige el repositorio.
4. Deja el comando de build vacío.
5. Usa `.` como directorio de publicación (o el campo de publicación indicado por Netlify para la raíz del proyecto).
6. Publica el sitio.

## Antes de publicar

Busca y reemplaza los marcadores:
- `[Tu nombre]` y `[Tu nombre completo]`
- `[TU_CORREO]`
- `[URL_GITHUB]`
- `[URL_LINKEDIN]`
- `[URL_REPOSITORIO]`, `[URL_DEMO]` y los campos académicos

También actualiza la descripción SEO en `index.html`.

## Archivos

- `index.html`: contenido y estructura del sitio.
- `styles.css`: diseño adaptable y estilos visuales.
- `script.js`: menú móvil y año del footer.
- `assets/favicon.svg`: icono del sitio.

Las imágenes de iconos y tipografías se cargan desde servicios externos; requieren conexión a internet.
